package com.mss;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbOutputTerminal;
import com.ibm.broker.plugin.MbUserException;

public class Property_file_creation_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage inMessage = inAssembly.getMessage();
		MbMessageAssembly outAssembly = null;
		try {
			// create new message as a copy of the input
			MbMessage outMessage = new MbMessage(inMessage);
			outAssembly = new MbMessageAssembly(inAssembly, outMessage);
			// ----------------------------------------------------------
			// Add user code below

	Properties p=new Properties();
	p.setProperty("mcity", "vzm");
	p.setProperty("heights", "vsp");
	
	
	File file = new File("E:/test2.properties");
	FileOutputStream fileOut = new FileOutputStream(file);
	p.store(fileOut, "Favorite Things");
			
	FileInputStream fi=new FileInputStream(file);
	
	p.load(fi);
	
	
	String s=p.getProperty("heights");
	String s1=p.getProperty("mcity");
	
	fileOut.close();
	fi.close();
	
	MbElement xmlnsc=outMessage.getRootElement().getFirstElementByPath("XMLNSC");
	MbElement emp=xmlnsc.createElementAsLastChild(MbElement.TYPE_NAME,"EMP",null);
	emp.createElementAsLastChild(MbElement.TYPE_NAME,"C_Name",s);
	emp.createElementAsLastChild(MbElement.TYPE_NAME,"C_Address",s1);
	
	MbElement check=xmlnsc.getFirstChild();
	check.detach();
	
	
	
	
			// End of user code
			// ----------------------------------------------------------
		} catch (MbException e) {
			// Re-throw to allow Broker handling of MbException
			throw e;
		} catch (RuntimeException e) {
			// Re-throw to allow Broker handling of RuntimeException
			throw e;
		} catch (Exception e) {
			// Consider replacing Exception with type(s) thrown by user code
			// Example handling ensures all exceptions are re-thrown to be handled in the flow
			throw new MbUserException(this, "evaluate()", "", "", e.toString(),
					null);
		}
		// The following should only be changed
		// if not propagating message to the 'out' terminal
		out.propagate(outAssembly);

	}

}
